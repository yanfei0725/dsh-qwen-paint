/**
 * _step4_e2e.mjs —— 真机 A/B：8 步（turbo8）vs 4 步（Lightning 4steps）。
 *
 * 验两件事：
 *   ① 「4 步权重能不能叠我们的优化链」—— 走**真的** buildWorkflow，
 *      并断言 4 步那份图里 LoRA / 前缀缓存 / TE-Speed+Speedup / FA 都在；
 *   ② 实测总耗时差多少（同尺寸、同 seed，唯一变量是步数与 LoRA）。
 *
 * 用法：node scripts/_step4_e2e.mjs
 * ComfyUI 不在线则跳过（不算失败）。
 */
import { promises as fsp } from 'node:fs'
import path from 'node:path'
import os from 'node:os'

process.env.DSHQP_DIAG = '0'
const ROOT = path.resolve(import.meta.dirname, '..')
const mod = await import('file://' + path.join(ROOT, 'lib', 'index.js').replace(/\\/g, '/'))
const { DEFAULTS, buildWorkflow, probeCapabilities } = mod.__internal

const COMFY = 'http://127.0.0.1:8188'
const LORA4 = 'Qwen-Image-Lightning-4steps-V2.0-bf16.safetensors'
const SIZE = 1024
const SEED = 20261012
const PROMPT = '一只戴草帽的橘猫坐在窗台上，午后阳光，画面右上角写着"午后"两个字'

// ---- ComfyUI 在不在 ----
try {
  const r = await fetch(`${COMFY}/system_stats`, { signal: AbortSignal.timeout(4000) })
  if (!r.ok) throw new Error(String(r.status))
} catch {
  console.log(`⚠ ComfyUI (${COMFY}) 不在线 → 跳过真机测试`)
  process.exit(0)
}
console.log(`✓ ComfyUI 在线`)

const logs = []
const log = (lv, m) => { logs.push([lv, m]) }
const cfg = { ...DEFAULTS, comfyUrl: COMFY, outputDir: path.join(os.tmpdir(), '_qwen_step4') }

// ---- 真探测一次（拿到 unet/clip/vae 等真实文件名）----
console.log('… 能力探测中')
const caps = await probeCapabilities(cfg, log, null)
console.log(`  探测到：unet=${caps.models.unet}`)
console.log(`          clip=${caps.models.clip}`)
console.log(`          vae=${caps.models.vae}`)
console.log(`          lora=${caps.models.turbo8Lora}   ← 探测阶段自动选的（按 turbo8 关键字）`)
console.log(`  level=${caps.level}`)

async function generate(label, { steps, lora, forceLock, seed, maxShift, baseShift }) {
  const c = { ...caps, models: { ...caps.models, turbo8Lora: lora } }
  const runCfg = forceLock === undefined ? { ...cfg } : { ...cfg, forceTurbo8Steps: forceLock, turbo8Steps: steps }
  if (Number.isFinite(maxShift)) runCfg.turbo8MaxShift = maxShift
  if (Number.isFinite(baseShift)) runCfg.turbo8BaseShift = baseShift
  const cfgRun = runCfg

  const res = buildWorkflow(cfgRun, {
    prompt: PROMPT, negative: '', width: SIZE, height: SIZE, seed: seed ?? SEED, count: 1,
  }, c)
  const wf = res?.workflow ?? res
  const nodes = Object.values(wf).filter((n) => n && typeof n === 'object' && n.class_type)
  const types = nodes.map((n) => n.class_type)
  const sampler = nodes.find((n) => n.class_type === 'KSampler')
  const loraNode = nodes.find((n) => n.class_type === 'LoraLoaderModelOnly')

  console.log(`\n=== ${label} ===`)
  console.log(`  KSampler: steps=${sampler?.inputs?.steps} cfg=${sampler?.inputs?.cfg}`)
  console.log(`  LoRA    : ${loraNode?.inputs?.lora_name}`)
  console.log(`  优化节点: ${types.filter((t) => /TESpeed|Speedup|BlockCache|Cache|FlashAttention/i.test(t)).join(', ') || '（无）'}`)

  const t0 = Date.now()
  const sub = await fetch(`${COMFY}/prompt`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ prompt: wf, client_id: 'dshqp-step4-test' }),
  })
  if (!sub.ok) {
    console.log(`  ✗ 提交失败 HTTP ${sub.status}: ${(await sub.text()).slice(0, 300)}`)
    return { label, ok: false }
  }
  const { prompt_id } = await sub.json()
  let hist = null
  for (;;) {
    await new Promise((r) => setTimeout(r, 1500))
    const h = await fetch(`${COMFY}/history/${prompt_id}`).then((r) => r.json()).catch(() => ({}))
    if (h?.[prompt_id]) { hist = h[prompt_id]; break }
    if (Date.now() - t0 > 900000) { console.log('  ✗ 超时 15 分钟'); return { label, ok: false } }
  }
  const secs = (Date.now() - t0) / 1000
  const imgs = Object.values(hist.outputs ?? {}).flatMap((o) => o.images ?? [])
  console.log(`  ⏱  实测总耗时：${secs.toFixed(1)} s`)
  console.log(`  产出：${imgs.map((i) => i.filename).join(', ') || '（无图）'}`)

  // 落盘一份供肉眼比对
  if (imgs[0]) {
    const url = `${COMFY}/view?filename=${encodeURIComponent(imgs[0].filename)}&subfolder=${encodeURIComponent(imgs[0].subfolder ?? '')}&type=${imgs[0].type ?? 'output'}`
    const buf = Buffer.from(await (await fetch(url)).arrayBuffer())
    await fsp.mkdir(cfg.outputDir, { recursive: true })
    const out = path.join(cfg.outputDir, `${label.replace(/[^\w]/g, '_')}.png`)
    await fsp.writeFile(out, buf)
    console.log(`  已存：${out}（${buf.length} B）`)
  }
  return { label, ok: true, secs, steps: sampler?.inputs?.steps, lora: loraNode?.inputs?.lora_name }
}

// ⚠ 每笔**必须换 seed** —— 否则 ComfyUI 执行缓存直接命中（1.5 s 返回同一张图），
//   测出来的不是"出图耗时"而是"查缓存耗时"。这是踩过的坑。
//
// 本轮专测【采样位移】的影响：
//   插件默认 max_shift=0.6935(=ln2) 是 **turbo8 的工作点**（turbo8 按 shift=2 蒸馏）；
//   而 Lightning 官方 README 写明 "shift=3 in distillation" ⇒ 对应 ln(3)≈1.0986。
//   拿 shift=2 去跑按 shift=3 蒸馏的 LoRA，画质会崩 —— 必须先排除这个变量。
const TURBO8_SHIFT = 0.6935
const LIGHTNING_SHIFT = Math.log(3)   // ≈ 1.0986

await generate('W_预热_丢弃', { steps: 8, lora: caps.models.turbo8Lora ?? 'turbo8_lora_step2500.safetensors', forceLock: true, seed: 1001 })
const base8 = await generate('A_8步_turbo8_默认位移', {
  steps: 8, lora: caps.models.turbo8Lora ?? 'turbo8_lora_step2500.safetensors', forceLock: true, seed: 1002,
})
const s4_bad = await generate('B_4步_lightning_turbo8位移', { steps: 4, lora: LORA4, forceLock: false, seed: 2001, maxShift: TURBO8_SHIFT, baseShift: 0.5 })
const s4_ok = await generate('C_4步_lightning_Lightning位移', { steps: 4, lora: LORA4, forceLock: false, seed: 2001, maxShift: LIGHTNING_SHIFT, baseShift: LIGHTNING_SHIFT })

console.log('\n=== 汇总（全部热态，每笔不同 seed）===')
const fmt = (r) => (r.ok ? `${r.secs.toFixed(1)} s` : '失败')
console.log(`  8 步 turbo8（默认位移）        : ${fmt(base8)}`)
console.log(`  4 步 Lightning + turbo8位移    : ${fmt(s4_bad)}   ← 位移不匹配`)
console.log(`  4 步 Lightning + Lightning位移 : ${fmt(s4_ok)}   ← 位移匹配（ln3）`)
console.log('  ⚠ 画质请看落盘的两张 B/C 图对比（同 seed 2001，唯一变量是位移）')



