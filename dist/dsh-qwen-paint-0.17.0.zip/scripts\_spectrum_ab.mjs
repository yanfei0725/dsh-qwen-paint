/**
 * _spectrum_ab.mjs —— **Spectrum 跳步加速的真机 A/B 实测**。
 *
 * 这不是回归测试，是**测量工具**：用来回答"Spectrum 在本插件的 8 步链路下到底有没有收益"。
 *
 * ## 为什么必须实测而不是照抄第三方数字
 *   用户反馈里给的加速倍数是**论文/第三方 README 的数字**（SADA 1.2–2.0× 等），
 *   而本插件跑的是 **turbo8 八步蒸馏链**。Spectrum 的默认参数是为**常规步数**调的：
 *     `warmup_steps=5` + `tail_actual_steps=2` ⇒ **8 步里只剩 1 步可跳**，
 *     收益很可能被预测器自身（切比雪夫拟合）的开销吃掉，**甚至更慢**。
 *   ⇒ 所以这里三个变体都跑：**基线 / 默认参数 / 针对 8 步调小 warmup+tail**。
 *
 * ## 它怎么保证可比
 *   · 同一个 prompt、同一个尺寸；
 *   · **每次生成都用不同的 seed，但各变体用同一组 seed**（见下面 SEEDS 的注释）——
 *     ⚠⚠ **这是本脚本最容易错的地方**：ComfyUI 有**执行缓存**，同一个 prompt + 同一个 seed
 *     会直接返回上次的结果（实测：整单 1.0 s 就"完成"，那是查缓存不是出图）。
 *     我第一版就是每个变体固定一个 seed ⇒ 得到"A 1.0s / B 15.1s / C 17.3s"这种
 *     **完全失真**的数字（A 其实是命中了预热那张的缓存）。
 *   · **先跑一张预热**（把 13.5 GB 模型装进显存），避免把加载时间算进来；
 *   · 每个变体跑 REPS 次取中位数；
 *   · 图都存下来，供**肉眼对比画质**（节点作者自述"不替你评估画质"，必须自己看）。
 *
 * 用法：node scripts/_spectrum_ab.mjs [宽] [高]
 * ComfyUI 不在线时**明确跳过**（不假装跑过）。
 */
import { mkdirSync } from 'node:fs'
import path from 'node:path'
import { fileURLToPath, pathToFileURL } from 'node:url'

process.env.DSHQP_DIAG = '0'
const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..')
const mod = await import(pathToFileURL(path.join(ROOT, 'lib', 'index.js')).href)
const { DEFAULTS, buildWorkflow, probeCapabilities } = mod.__internal

const COMFY = DEFAULTS.comfyUrl ?? 'http://127.0.0.1:8188'
const W = Number(process.argv[2] ?? 1024)
const H = Number(process.argv[3] ?? 1024)
const PROMPT = '一只橘猫戴着草帽趴在窗台上，午后阳光，画面右上角写「午后」两个字'
const REPS = 2
/**
 * ★★★ 每个变体**固定用同一组 seed**，但**同一变体内每次不同**。
 *   同一组 ⇒ 变体之间可比；每次不同 ⇒ 不会命中 ComfyUI 的执行缓存。
 *   ⚠ 千万别改成"所有变体共用一个 seed" —— 那会让第 2 次起全部变成缓存命中（1.0s）。
 */
const SEEDS = [20261012, 20261013, 20261014, 20261015, 20261016]
const WARMUP_SEED = 999999 // 预热专用，不参与任何变体，避免污染缓存
const OUT = path.join(ROOT, '_spectrum-ab-out')

const ok = (n, x) => console.log('  OK  ', n, x ?? '')
const bad = (n, x) => console.log('  FAIL', n, x ?? '')

// ---- 0. 在线检查 ----
let online = false
try {
  const r = await fetch(`${COMFY}/system_stats`, { signal: AbortSignal.timeout(4000) })
  online = r.ok
} catch { online = false }
if (!online) {
  console.log(`⚠ ComfyUI (${COMFY}) 不在线 → **跳过 A/B 实测**（这不是失败，是没条件）`)
  console.log('  想跑：先启动 ComfyUI，再执行 node scripts/_spectrum_ab.mjs')
  process.exit(0)
}
ok('ComfyUI 在线', COMFY)
mkdirSync(OUT, { recursive: true })

// ---- 1. 真探测（拿到本机真实的节点可用性）----
const caps = await probeCapabilities({ ...DEFAULTS, comfyUrl: COMFY }, () => {}, undefined)
ok('探测完成：vramGB=' + (caps.gpu?.vramGB ?? '?') + '  节点 vaeTiled=' + caps.nodes?.vaeTiled
  + ' spectrum=' + caps.nodes?.spectrum)
if (caps.nodes?.spectrum !== true) {
  console.log('\n⚠ 本机**没有** QwenSpectrumModelPatcher 节点 → 无法测 Spectrum，只跑基线。')
}

/** 构造一个变体的 workflow（seed 由调用方给 —— 见 SEEDS 的注释）。 */
const build = (cfg, seed) => {
  const r = buildWorkflow({ ...DEFAULTS, ...cfg },
    { prompt: PROMPT, width: W, height: H, seed, count: 1 }, caps)
  return r?.workflow ?? r
}

/** 提交一个 prompt 并等到完成；返回 { secs, promptId, images }。 */
async function submit(workflow, tag) {
  const t0 = Date.now()
  const post = await fetch(`${COMFY}/prompt`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ prompt: workflow, client_id: 'dshqp-ab' }),
  })
  if (!post.ok) {
    const t = await post.text().catch(() => '')
    throw new Error(`提交失败 ${post.status}: ${t.slice(0, 400)}`)
  }
  const { prompt_id: pid } = await post.json()

  // 轮询 history（比 websocket 简单、够用）
  for (let i = 0; i < 600; i += 1) {
    await new Promise((r) => setTimeout(r, 1000))
    const h = await fetch(`${COMFY}/history/${pid}`, { signal: AbortSignal.timeout(5000) }).then((r) => r.json()).catch(() => null)
    const rec = h?.[pid]
    if (rec) {
      const secs = (Date.now() - t0) / 1000
      const images = []
      for (const n of Object.values(rec.outputs ?? {})) {
        for (const im of (n.images ?? [])) {
          images.push(im)
          try {
            const u = `${COMFY}/view?filename=${encodeURIComponent(im.filename)}`
              + `&subfolder=${encodeURIComponent(im.subfolder ?? '')}&type=${im.type ?? 'output'}`
            const b = await fetch(u, { signal: AbortSignal.timeout(30000) })
            const buf = Buffer.from(await b.arrayBuffer())
            // ⚠ tag 里可能有 `/`（例如 "warmup5/tail2"）—— 直接拿来拼文件名会变成"不存在的子目录"，
            //   然后被下面 catch 静默吞掉 ⇒ 图一张都没存下来（第一版就是这么丢的 B/C 图）。
            const safe = String(tag).replace(/[\\/:*?"<>|]/gu, '-')
            const f = path.join(OUT, `${safe}__${im.filename}`)
            await (await import('node:fs/promises')).writeFile(f, buf)
          } catch (e) {
            console.log('    ⚠ 落盘失败：', e?.message ?? e)
          }
        }
      }
      return { secs, promptId: pid, images }
    }
  }
  throw new Error('等待超时（600s）')
}

/** 跑一个变体 REPS 次，返回中位数。 */
async function measure(tag, cfg) {
  const times = []
  for (let i = 0; i < REPS; i += 1) {
    // ★ 每个变体都用 **SEEDS[i]** ⇒ 变体之间可比；同一变体内每次不同 ⇒ 不命中缓存
    const seed = SEEDS[i % SEEDS.length]
    try {
      const r = await submit(build(cfg, seed), `${tag}_seed${seed}`)
      if (r.secs < 3) {
        // 防御：真出图不可能 < 3s，出现就是缓存命中
        bad(`${tag} 第 ${i + 1} 次：${r.secs.toFixed(1)}s —— **疑似缓存命中，本次不计入**`)
        continue
      }
      times.push(r.secs)
      process.stdout.write(`    · ${tag} 第 ${i + 1} 次（seed ${seed}）：${r.secs.toFixed(1)}s\n`)
    } catch (e) {
      bad(`${tag} 第 ${i + 1} 次`, e?.message ?? e)
      return null
    }
  }
  if (times.length === 0) return null
  times.sort((a, b) => a - b)
  return { tag, median: times[Math.floor(times.length / 2)], all: times }
}

console.log('\n=== 预热（这一张不计入成绩：把 13.5 GB 模型装进显存）===')
try {
  const w = await submit(build({}, WARMUP_SEED), 'warmup')
  ok('预热完成', `${w.secs.toFixed(1)}s（含模型加载，不算成绩）`)
} catch (e) {
  bad('预热失败', e?.message ?? e)
  process.exit(1)
}

const variants = [
  { tag: 'A_基线（不接 Spectrum）', cfg: {} },
  ...(caps.nodes?.spectrum === true
    ? [
      { tag: 'B_Spectrum默认(warmup5/tail2)', cfg: { spectrumEnabled: true } },
      { tag: 'C_Spectrum针对8步(warmup2/tail1)', cfg: { spectrumEnabled: true, spectrumWarmupSteps: 2, spectrumTailActualSteps: 1 } },
    ]
    : []),
]

console.log(`\n=== 正式测量（${W}x${H} · 每变体 ${REPS} 次取中位数，各变体用同一组 seed ${SEEDS.slice(0, REPS).join(' / ')}）===`)
const results = []
for (const v of variants) {
  const r = await measure(v.tag, v.cfg)
  if (r) results.push(r)
}

console.log('\n=== 结果 ===')
const base = results.find((r) => r.tag.startsWith('A_'))
for (const r of results) {
  const delta = base && r !== base
    ? `  vs 基线：${(r.median - base.median > 0 ? '+' : '')}${(r.median - base.median).toFixed(1)}s`
      + `（${((base.median / r.median - 1) * 100 >= 0 ? '+' : '')}${((base.median / r.median - 1) * 100).toFixed(1)}%）`
    : ''
  console.log(`  ${r.tag}: 中位数 ${r.median.toFixed(1)}s  全部 ${r.all.map((x) => x.toFixed(1)).join(' / ')}${delta}`)
}
console.log(`\n图都存到了：${OUT}`)
console.log('⚠ 请**自己看图对比画质** —— 节点作者原话："The node does not score image quality for you."')
console.log('  尤其看右上角「午后」两个字（4 步/跳步类加速最容易先崩中文文字渲染）。')

if (!caps.nodes?.spectrum) {
  console.log('\n（本机没有 Spectrum 节点 ⇒ 只跑了基线，无法给出加速比。）')
} else if (results.length >= 2) {
  const best = results.slice(1).reduce((a, b) => (a.median <= b.median ? a : b))
  const gain = (base.median / best.median - 1) * 100
  console.log(`\n最快的变体：${best.tag} ⇒ 相对基线 ${gain >= 0 ? '快' : '慢'} ${Math.abs(gain).toFixed(1)}%`)
  console.log(gain > 5
    ? '  ⇒ 有可观测收益，可以考虑把该变体的参数设为 Spectrum 的插件默认值（**但仍需先确认画质无可见差异**）。'
    : '  ⇒ 收益在噪声范围内 ⇒ **建议保持默认关**（这也是插件当前的默认值）。')
}
